#include "tic.h"


Tic::Tic(){
    char number = '1';
    for(int i = 0 ; i < 3 ; i++){
        for(int j = 0 ; j < 3 ; j++){
            table[i][j] = number;
            number++ ;
            
        }
    }
}
Tic::~Tic(){}
void Tic::show_table(){
    for(int i = 0 ; i < 3 ; i++){
        for(int j = 0 ; j < 3 ; j++){
            std::cout << "| " << table[i][j] << " |";
        }
        std::cout << std::endl << "---------------" << std::endl;
    }
}
void Tic::get_num(int counter){
    bool flag = true;
    std::cout << "\nwarning!!!\nif you enter a number more than 1 digit, only the first digit will be accepted.\n";
    
    while(flag){
        if(counter % 2 == 1){
            std::cout << "\nO: ";
        }
        else if(counter % 2 == 0){
            std::cout << "\nX: ";
        }
        std::cin >> num;
        if(num < '1' && num > '9'){
            std::cout << "this number isnt in the range!try again.\n";
        }
        else{
            bool in_or_not = false;
            for(int i = 0 ; i < 3 ; i++){
                for(int j = 0 ; j < 3 ; j++){
                    std::string str_num;
                    str_num = num ;
                    if(table[i][j] == str_num){
                        in_or_not = true ;
                        flag = false;
                        break;
                    }
                    
                }
            }
            if(!in_or_not){
                std::cout << "this number have been chosen!try another one.\n" ;
            }

        }
    }

}
void Tic::set(int counter){
    for(int i = 0 ; i < 3 ; i++){
        for(int j = 0 ; j < 3 ; j++){
            std::string str_num ;
            str_num = num;
            if(table[i][j] == str_num && counter % 2 == 1){
                table[i][j] = "O";
            }
            else if(table[i][j] == str_num && counter % 2 == 0){
                table[i][j] = "X";
            }
        }
    }
}

void Tic::check_winner(int counter, bool& flag){
    for(int i = 0 ; i < 3 ; i++){
        if((table[i][0] == table[i][1] && table[i][1] == table[i][2]) || (table[0][i] == table[1][i] && table[1][i] == table[2][i]) ||( table[0][0] == table[1][1] && table[1][1] == table[2][2]) || (table[0][2] == table[1][1] && table[1][1] == table[2][0]) ){
            if(counter % 2 == 1){
                std::cout << "\nplayer O wonnnnnnn!!\nwinner winner chicken dinner!\n" ; 
                flag = false ;
                break;

            }
            else if (counter % 2 == 0){
                std::cout << "\nplayer X wonnnnnnn!!\nwinner winner chicken dinner!\n" ; 
                flag = false ;
                break;
            }
        }
        else if(counter == 9){
            std::cout << "\nno winner :((\n";
            flag = false ;
            break;
        }
    }
}
