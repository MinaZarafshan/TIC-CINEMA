#ifndef TIC_H
#define TIC_H
#include <iostream>
#include <string>
#include <cstring>


class Tic{
    private:
        std::string table[3][3];
        char num ;

    public:
        Tic();
        ~Tic();
        void get_num(int counter) ;
        void show_table();
        void set(int counter);
        bool check(int counter) ;
        void check_winner(int counter, bool& flag);

};






#endif