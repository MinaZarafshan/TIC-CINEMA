#include "tic.h"

int main(){
    std::cout << "welcome to tic tac toe game!\n";
    bool flag = true ;
    Tic tac;
    int counter = 1 ;
    while(flag){
        tac.show_table();
        tac.get_num(counter);
        tac.set(counter);
        tac.check_winner(counter, flag);
        if(!flag){
            std::cout << std::endl;
            tac.show_table();
        }
        counter++;
    }
    return 0 ;
}