#ifndef THEATER_H
#define THEATER_H
#include <iostream>
#include <string>


struct Movie{
    std::string name ;
    int seat[5][5];
};

class Theater{

    public:
        Movie movie[2];
        std::string name;
        
        int rows, colums;
        Theater();
        ~Theater();
};


#endif