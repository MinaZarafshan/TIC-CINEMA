#include "City.h"

City::City(){
    theaters[0].name = "1";
    theaters[1].name = "2";
    theaters[2].name = "3";
    theaters[0].rows = 3;
    theaters[1].rows = 4;
    theaters[2].rows = 2;
    for(int i = 0 ; i < 3 ; i++){
        int number = 1;
        theaters[i].colums = 2;
        for(int j = 0 ; j < theaters[i].rows  ; j++){
            for(int k = 0 ; k < theaters[i].colums ; k++){
                theaters[i].movie[0].seat[j][k] = number;
                theaters[i].movie[1].seat[j][k] = number;
                number++;
            } 
        }    
    }   
}
City::~City(){}
void City::print(int theater_num, int & number ){
    if(theater_num < 1 && theater_num > 3){
        std::cerr << "\nyour selection must be in range!!\n";
        return;
    }
    std::cout << "\nMovie 1: " << theaters[theater_num-1].movie[0].name << "\nMovie 2: " << theaters[theater_num-1].movie[1].name << std::endl << 
    "enter a number(1 or 2): ";
    bool flag = true ;
    while(flag){
        std::cin >> number;
        std::cout << "-------------------\n";
        if( number == 1 || number == 2){
            for(int i = 0 ; i < theaters[theater_num-1].rows ; i++){
                for(int j = 0 ; j < 2 ; j++){
                    if(theaters[theater_num-1].movie[number-1].seat[i][j] == -1){
                        std::cout << " [X] ";
                    }
                    else{
                        std::cout << " [" <<theaters[theater_num-1].movie[number-1].seat[i][j] << "] ";
                    }
                }
                std::cout << std::endl;
            }
            flag = false;
            break;
        }
        else{
            std::cout << "\nyour number inst in range!\nenter again: ";
        }
    }   
}
void City::selection(int theater_num, int number){
    bool flag = true ;
    while(flag){
        std:: cout << "\nselect a seat number: \n";
        int seat;
        std::cin >> seat;
        if(seat > 0 && seat <= theaters[theater_num-1].rows * 2 ){
            bool right = false;
            for(int i = 0 ; i < theaters[theater_num-1].rows ; i++){
                for(int j = 0 ; j < 2 ; j++){
                    if(theaters[theater_num-1].movie[number - 1].seat[i][j] == seat){
                        theaters[theater_num-1].movie[number - 1].seat[i][j] = -1;
                        flag = false;
                        right = true;
                        std::cout << "\nThe reservation was successful.\n";
                        break;
                    }
                    else if(theaters[theater_num-1].movie[number - 1].seat[i][j] == -1){
                        std::cout << "\nthis seat have been reserved before!\n";
                    } 
                }
            }
        }
        else{
            std::cout << "\nyou should select a number in range!\n";
        }  
    }    
}


