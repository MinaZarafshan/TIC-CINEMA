#ifndef CITY_H
#define CITY_H
#include "theater.h"

class City{
    private:
        Theater theaters[3];
        
    public:
        City();
        ~City();
        void print(int theater_num, int & number);
        void selection(int theater_num, int number);


};




#endif