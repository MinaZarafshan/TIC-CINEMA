#include "City.h"

int main(){
    City Mashad;
    bool flag = true;
    while(flag){
        int number = 0;
        std::cout << "Welcome to the cinema seat reservation system!\n1.Theater 1\n2.Theater 2\n3.Theater 3\n4.exit\nselect a theater:  ";
        std::string command;
        std::cin >> command;
        Mashad.print(stoi(command), number);
        Mashad.selection(stoi(command), number);
        if(command == "exit"){
            flag = false;
            break;
        }
    }
    return 0;
}