#include "theater.h"


Theater::Theater(){
    movie[0].name = "Despicable Me";
    movie[1].name = "Rapunzel";
}
Theater::~Theater(){}